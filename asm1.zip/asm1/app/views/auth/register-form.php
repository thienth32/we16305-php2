<form action="<?= BASE_URL . 'tao-tai-khoan'?>" method="post">
    <div>
        <label for="">Tên</label>
        <input type="text" name="name">
    </div>
    <div>
        <label for="">Email</label>
        <input type="text" name="email">
    </div>
    <div>
        <label for="">Password</label>
        <input type="password" name="password">
    </div>
    <div>
        <button type="submit">Đăng ký</button>
    </div>
</form>