<form action="<?= BASE_URL . 'mon-hoc/luu-tao-moi'?>" method="post">
    <div>
        <label for="">Tên danh mục</label>
        <input type="text" name="name">
    </div>
    <div>
        <button type="submit">Lưu</button>
    </div>
</form>