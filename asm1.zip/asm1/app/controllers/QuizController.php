<?php
namespace App\Controllers;
class QuizController{
    
}
?>