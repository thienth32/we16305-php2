<?php
namespace App\Models;
class Subject extends BaseModel{
    protected $tableName = 'subjects';
}
?>