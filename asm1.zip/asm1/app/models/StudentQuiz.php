<?php
namespace App\Models;
class StudentQuiz extends BaseModel{
    protected $tableName = 'student_quizs';
}
?>