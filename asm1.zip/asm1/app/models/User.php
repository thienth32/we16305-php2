<?php
namespace App\Models;
class User extends BaseModel{
    protected $tableName = 'users';
}
?>