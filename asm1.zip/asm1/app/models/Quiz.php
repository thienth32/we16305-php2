<?php
namespace App\Models;
class Quiz extends BaseModel{
    protected $tableName = 'quizs';
}
?>