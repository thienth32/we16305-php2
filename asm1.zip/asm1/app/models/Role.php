<?php
namespace App\Models;
class Role extends BaseModel{
    protected $tableName = 'roles';
}
?>