<?php
namespace App\Models;
class Answer extends BaseModel{
    protected $tableName = 'answers';
}
?>