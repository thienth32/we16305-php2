<?php
namespace App\Models;
class StudentQuizDetail extends BaseModel{
    protected $tableName = 'student_quiz_detail';
}
?>