<?php
namespace App\Models;
class Question extends BaseModel{
    protected $tableName = 'questions';
}
?>