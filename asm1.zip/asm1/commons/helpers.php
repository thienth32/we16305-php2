<?php

const BASE_URL = "http://localhost/we16305-php2/asm1/";

?>